import 'dart:convert';

import 'package:draggable/draggable_widget.dart';
import 'package:draggable/postioned_json.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/diagnostics.dart';

class JsonPostioning extends Positioned {
  JsonPostioning(
      {required super.child, required super.left, required super.top});

  Map<String, dynamic> toJson() {
    var jsonChild = jsonEncode(child);
    return {
      jsonEncode("type"): jsonEncode("positioned"),
      jsonEncode("args"): {jsonEncode("left"): left, jsonEncode("top"): top},
      jsonEncode("child"): jsonChild,
    };
  }
}
