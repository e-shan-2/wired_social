import 'package:draggable/draggable_widget.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class JsonPostioned extends DraggableWidget<JsonPostioned> {
  double left;
  double top;
  final Offset initContPos;

  JsonPostioned(
      {super.data,
      super.key,
      // super.type = DraggableWidgetType.none,
      required this.child,
      this.initContPos = const Offset(0, 0),
      required this.left,
      required this.top});

  @override
  JsonPostioned modify(
      {Key? key, DraggableWidgetType? type, JsonPostioned? data}) {
    return JsonPostioned(
      left: left,
      top: top,
      key: key,
      // type: this.type,
      data: data ?? this.data,
      child: child,
    );
  }

  DraggableWidget? child;

  @override
  Map<String, dynamic> toJson() {
    var jsonChild;

    if (child != null) {
      jsonChild = child!.toJson();
    }
    print(jsonChild);
    return {
      "type": "positioned",
      "args": {"left": left, "top": top},
      "child": jsonChild,
    };
  }

  @override
  State<JsonPostioned> createState() => _JsonPostionedState();
}

class _JsonPostionedState extends State<JsonPostioned> {
  Offset position = const Offset(0.0, 0.0);

  @override
  void initState() {
    position = widget.initContPos;
  }

  @override
  Widget build(BuildContext context) {
    JsonPostioned widgetData = widget.data ?? widget;

    return JsonPostioned(
      left: widget.left,
      top: widget.top,
      child: widget.child,
    );
    //  Draggable(
    //   data: widgetData.modify(key: widget.key),
    //   feedback: JsonPostioned(
    //     left: widget.left,
    //     top: widget.top,
    //     child: widget.child,
    //   ),
    //   childWhenDragging: JsonPostioned(
    //     left: widget.left,
    //     top: widget.top,
    //     child: widget.child,
    //   ),
    //   child: JsonPostioned(
    //     left: widget.left,
    //     top: widget.top,
    //     child: widget.child,
    //   ),
    // );

    // Positioned(left: left, top: top, child: child);
  }
}
