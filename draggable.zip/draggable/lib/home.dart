import 'dart:convert';
import 'dart:ui';

import 'package:dotted_border/dotted_border.dart';
import 'package:draggable/circle_avatar.dart';
import 'package:draggable/code/positioned_josonwidget.dart';
import 'package:draggable/custom_card.dart';
import 'package:draggable/custom_container.dart';
import 'package:draggable/custom_floating_action_button.dart';
import 'package:draggable/custom_text_form_field.dart';
import 'package:draggable/draggable_widget.dart';
import 'package:draggable/postioned_json.dart';
import 'package:flutter/material.dart';

class MyHome extends StatefulWidget {
  const MyHome({super.key});

  @override
  State<MyHome> createState() => _MyHomeState();
}

class _MyHomeState extends State<MyHome> {
  Offset position = const Offset(0.0, 0.0);
  Color caughtColor = Colors.white;
  List<JsonPostioning> recievewidgets = [];
  List<Map<String, dynamic>> dataItems = [];

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      body: Row(children: [
        Container(
            color: Colors.cyanAccent,
            width: size.width * .2,
            height: size.height,
            child: Column(
              children: [
                const SizedBox(
                  height: 20,
                ),

                MyCustomCircleAvatar(
                  itemColor: Colors.redAccent,
                  initPos: Offset(10, 10),
                ).create(),
                const SizedBox(
                  height: 20,
                ),
                MyCustomContainer(
                  itemContColor: Colors.blueAccent,
                  initContPos: const Offset(10, 10),
                ).create(),
                const SizedBox(
                  height: 20,
                ),
                MyCustomCard(
                  initCardPos: const Offset(10, 10),
                  itemCardColor: Colors.amberAccent,
                ).create(),
                const SizedBox(
                  height: 20,
                ),

                MyCustomTextFormField(
                        itemFieldColor: Colors.white,
                        initContPos: const Offset(10, 10))
                    .create(),
                const SizedBox(
                  height: 20,
                ),
                MyCustomFloatingActionButton(
                  initContPos: const Offset(10, 10),
                  itemFieldColor: Colors.red,
                ).create()
                // Text("Hello"),
                // Card(
                //   color: Colors.amber,
                //   elevation: 1,
                //   shadowColor: Colors.black12,
                //   child: Text("hello"),
                // )

                // createMyCardDrag(
                //   itemContColor: Colors.white12,
                //   initContPost: const Offset(10, 10),
                // )
                // const CustomTextFormField()
              ],
            )),
        SizedBox(
          width: size.width * .6,
          height: size.height,
          child:
              //  DragTarget<CustomWidget>(
              //   onAcceptWithDetails: (details) {
              //     CustomWidget data;
              //   },
              // )

              DragTarget<DraggableWidget>(
            onAcceptWithDetails: (details) {
              DraggableWidget newWidget;

              // print(details.data.toJson());
              // print("_____________________**********************__________");
              // print(
              //   details.offset.dx - size.width * .2,
              // );

              if (details.data.type == DraggableWidgetType.created) {
                newWidget = details.data.modify(
                  key: UniqueKey(),
                );
              } else {
                newWidget = details.data;
              }

              JsonPostioning widget = JsonPostioning(
                left: details.offset.dx - size.width * .2,
                top: details.offset.dy,
                child: newWidget,
              );

              findByKey(Key? key, JsonPostioning element) {
                return (element.child as DraggableWidget).key == key;
              }

              if (newWidget.type == DraggableWidgetType.created) {
                // Why does it add without any SetState ??
                recievewidgets.add(widget);
                dataItems.add(widget.toJson());
              } else if (newWidget.type == DraggableWidgetType.move) {
                int indexAt = recievewidgets.indexWhere((element) {
                  return findByKey(newWidget.key, element);
                });

                // print(indexAt);

                if (indexAt >= 0) {
                  // Need to SetState to refresh List

                  setState(() {
                    // recievewidgets[indexAt] = widget;
                    recievewidgets.removeAt(indexAt);
                    dataItems.removeAt(indexAt);
                    recievewidgets.add(widget);
                    dataItems.add(widget.toJson());
                  });
                }
              }
            },
            builder: (
              BuildContext context,
              List<Widget?> accepted,
              List<dynamic> rejected,
            ) {
              print(dataItems);
              return SizedBox(
                width: size.width * .6,
                height: size.height,
                child: Stack(
                  // children: recievewidgets
                  //   ..insert(
                  //     0,
                  //     DottedBorder(
                  //       color: Colors.indigoAccent,
                  //       dashPattern: const [2, 4],
                  //       strokeWidth: 2,
                  //       child: Container(),
                  //     ),
                  //   ),
                  children: [
                    DottedBorder(
                      color: Colors.indigoAccent,
                      dashPattern: const [2, 4],
                      strokeWidth: 2,
                      child: Container(),
                    ),
                    ...recievewidgets
                  ],
                ),
              );
            },
          ),
        ),
        Container(
          width: size.width * .2,
          height: size.height,
          color: Colors.grey.withOpacity(0.5),
        )
      ]),
    );
  }
}
