import 'package:draggable/draggable_widget.dart';
import 'package:flutter/material.dart';

class MyCustomTextFormField extends DraggableWidget<MyCustomTextFormField> {
  final Offset initContPos;
  final Color itemFieldColor;

  MyCustomTextFormField({
    super.key,
    required this.itemFieldColor,
    required this.initContPos,
    super.data,
    super.type = DraggableWidgetType.move,
  });

  @override
  MyCustomTextFormField modify({
    Key? key,
    DraggableWidgetType? type,
    MyCustomTextFormField? data,
  }) {
    return MyCustomTextFormField(
      itemFieldColor: itemFieldColor,
      initContPos: initContPos,
      type: type ?? this.type,
      data: data ?? this.data,
      key: key ?? this.key,
    );
  }

  @override
  State<MyCustomTextFormField> createState() => _MyCustomTextFormFieldState();

  @override
  Map<String, dynamic> toJson() {
    // TODO: implement toJson
    throw UnimplementedError();
  }
}

class _MyCustomTextFormFieldState extends State<MyCustomTextFormField> {
  TextEditingController controller = TextEditingController();
  Offset position = const Offset(0.0, 0.0);

  @override
  void initState() {
    super.initState();
    position = widget.initContPos;
  }

  @override
  Widget build(BuildContext context) {
    MyCustomTextFormField widgetData = widget.data ?? widget;

    return Draggable(
        data: widgetData.modify(key: widget.key),
        feedback: Container(
          padding: const EdgeInsets.all(10),
          height: 50,
          width: 100,
        ),
        childWhenDragging: Container(
            padding: const EdgeInsets.all(10),
            height: 50,
            width: 200,
            child: TextFormField(
              controller: controller,
              decoration: const InputDecoration.collapsed(hintText: 'Text'),
            )),
        child: Container(
            padding: const EdgeInsets.all(10),
            height: 50,
            width: 200,
            child: TextFormField(
              controller: controller,
              decoration: const InputDecoration.collapsed(
                  hintText: 'Text', hintStyle: TextStyle(color: Colors.grey)),
            )));
  }
}
